// Test driver
#include <cctype>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

#include "StackTypeLinked.h"

using namespace std;

int main() {
    // Test the Print function.
    StackTypeLinked<int> myStack;
    myStack.Push(2);
    myStack.Push(5);
    myStack.Push(3);
    myStack.Print();
    cout << "StackSum: " << myStack.StackSum() << endl;
    cout << "Verify stack is restored:" << endl;
    myStack.Print();
    myStack.Pop();
    myStack.Pop();
    cout << "test a 1 item stack sum" << endl;
    cout << "StackSum: " << myStack.StackSum() << endl;
    cout << "Verify stack is restored:" << endl;
    myStack.Print();
    return 0;
}
