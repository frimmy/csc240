// Test driver
// Ivan Temesvari
// Updated operator[]
// 2/17/2022
// Templated version

#include <fstream>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

#include "StackType.h"

using namespace std;

int main() {
    StackType<int> myStack;
    myStack.Push(2);
    myStack.Push(5);
    myStack.Push(3);
    myStack.Print();
    cout << "StackSum: " << myStack.StackSum() << endl;
    cout << "Verify stack is restored:" << endl;
    myStack.Print();
    myStack.Pop();
    myStack.Pop();
    cout << "test a 1 item stack sum" << endl;
    cout << "StackSum: " << myStack.StackSum() << endl;
    cout << "Verify stack is restored:" << endl;
    myStack.Print();
}
